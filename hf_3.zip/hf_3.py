import random

# 1. A két lista megadása
fogalmak = ['majorság', 'hűbéres', 'jobbágy', 'nemes', 'tized', 'kilenced', 'robot',
            'szügyhám', 'vetésforgó', 'ugar', 'lovag']

meghatarozasok = ['Egy-egy nagybirtok vagy valamely részének igazgatási központja.',
                  'Aki örökletes használatra megkapja a földet.',
                  'Telkes paraszt, aki a földesúrtól kapott földön gazdálkodik.',
                  'Kiváltságos réteg.',
                  'Egyházi adó.',
                  'Földesúrnak beszolgáltatott adó.',
                  'Ötvenkét igás, vagy 104 kézimunka nap kötelezettség.',
                  'Igavonási találmány, melynek köszönhetően nem az állat nyakában van a húzó eszköz.',
                  'A termőföld használata évszakonként más és más.',
                  'Művelés alá nem vont terület.',
                  'Vagyonos katonai szolgálattevő lóval, páncéllal.']

# 2. Szótár készítése
fogalom_szotar = {fogalom: meghatarozas for fogalom, meghatarozas in zip(fogalmak, meghatarozasok)}

# 3. Véletlenszrü sorrend készítése
kerdesek = list(fogalom_szotar.values())
random.shuffle(kerdesek)
for meghatarozas in kerdesek:
    print("Fogalom meghatározás:", meghatarozas)

# 4. Kikérdezés
helyes_szam = 0
helytelen_szam = 0
megkerdezett_meghatarozasok = set()

for meghatarozas in kerdesek:
    if meghatarozas in megkerdezett_meghatarozasok:
        continue
    megkerdezett_meghatarozasok.add(meghatarozas)

    print("Fogalom meghatározás:", meghatarozas)
    valasz = input("Mi a fogalom? (Kilépés: END/Q/QUIT): ")


    if valasz.strip().lower() in ['end', 'q', 'quit']:
        print()
        print("Kilépés...")
        break

    valasz_ellenorzott = valasz.strip().lower()

    helyes_fogalom = None
    for fogalom, meghatarozas_szo in fogalom_szotar.items():
        if meghatarozas_szo == meghatarozas:
            helyes_fogalom = fogalom
            break

    if valasz_ellenorzott == helyes_fogalom.lower():
        print("Helyes válasz!")
        helyes_szam += 1
    else:
        print(f"Rossz válasz. Helyesen: {helyes_fogalom}")
        helytelen_szam += 1

# Eredmény kirása
osszes = helyes_szam + helytelen_szam
if osszes > 0:
    szazalek = (helyes_szam / osszes) * 100
else:
    szazalek = 0

print(f"Összesen {helyes_szam} helyes és {helytelen_szam} helytelen válaszod volt.")
print(f"Ez {szazalek:}% helyes válasz.")




